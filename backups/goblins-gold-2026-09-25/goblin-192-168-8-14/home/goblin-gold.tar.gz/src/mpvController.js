const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

// Standardized 720p30 video directory for all Goblins
const DEFAULT_MEDIA_ROOT = '/home/remote/media/video';
const LOG_DIR = '/home/remote/goblin/logs';
try { fs.mkdirSync(LOG_DIR, { recursive: true }); } catch (_) { }

// Optimized MPV configuration for Raspberry Pi 3B+ with 720p30 videos
// Testing shows --vo=drm DOES work on Pi3, --vo=gpu --gpu-context=drm does NOT
// All videos are standardized to 1280x720 @ 30fps H.264
const DEFAULT_HWDEC = process.env.GOBLIN_HWDEC || 'v4l2m2m-copy';
const ENV_EXTRA_ARGS = (process.env.GOBLIN_MPV_EXTRA_ARGS || '')
  .trim()
  .split(/\s+/)
  .filter(Boolean);

const DEFAULT_VO = process.env.GOBLIN_VO || 'drm';

const MPV_BASE_ARGS = [
  `--vo=${DEFAULT_VO}`,
  `--hwdec=${DEFAULT_HWDEC}`,
  '--fs',
  '--no-audio',  // Disable audio for video displays
  // Back to original working settings - slight judder is normal for 30fps on 60Hz
  '--video-sync=display-resample',
  '--interpolation=no',
  '--msg-level=all=error',
  '--no-terminal',
  '--no-input-default-bindings',
  '--no-osc',  // No on-screen controller
  '--no-osd-bar',  // No OSD bar
  ...ENV_EXTRA_ARGS,
];

class MPVController {
  constructor(options = {}) {
    this.process = null;
    this.currentVideo = null;
    this.mediaRoot = options.mediaRoot || DEFAULT_MEDIA_ROOT;
    this.extraArgs = Array.isArray(options.extraArgs) ? options.extraArgs : [];
    this.onEnd = null; // Callback when current video exits
  }

  async play(filename, options = {}) {
    await this.stop();

    const videoPath = path.isAbsolute(filename)
      ? filename
      : path.join(this.mediaRoot, filename);

    const args = [...MPV_BASE_ARGS, ...this.extraArgs];
    if (options.loop) args.push('--loop');
    if (options.audioDevice) args.push(`--audio-device=${options.audioDevice}`);
    if (options.displayFps) args.push(`--display-fps=${options.displayFps}`);
    const envConnector = process.env.GOBLIN_DRM_CONNECTOR;
    const envMode = process.env.GOBLIN_DRM_MODE;
    if (options.connector) args.push(`--drm-connector=${options.connector}`);
    else if (envConnector) args.push(`--drm-connector=${envConnector}`);
    if (options.mode) args.push(`--drm-mode=${options.mode}`);
    else if (envMode) args.push(`--drm-mode=${envMode}`);
    args.push(videoPath);

    this.process = spawn('mpv', args, {
      detached: false,
      stdio: ['ignore', 'ignore', 'pipe'] // capture only stderr for diagnostics
    });

    try {
      const logPath = path.join('/home/remote/goblin', 'logs', 'mpv.stderr.log');
      this.process.stderr.on('data', (buf) => {
        try { fs.appendFile(logPath, buf, () => { }); } catch (_) { }
      });
    } catch (_) { }

    this.currentVideo = filename;

    this.process.on('exit', () => {
      this.process = null;
      const finished = this.currentVideo;
      this.currentVideo = null;
      if (typeof this.onEnd === 'function') {
        try { this.onEnd(finished); } catch (_) { }
      }
    });

    return { success: true, playing: filename };
  }

  async stop() {
    if (this.process) {
      try { this.process.kill('SIGTERM'); } catch (_) { }
      await new Promise(r => setTimeout(r, 400));
      if (this.process) {
        try { this.process.kill('SIGKILL'); } catch (_) { }
      }
      this.process = null;
      this.currentVideo = null;
    }
  }
}

module.exports = MPVController;

